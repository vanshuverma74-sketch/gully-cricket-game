# gully-cricket-game
“A console-based Gully Cricket Game developed in C++ using OOP principles such as classes, objects, and encapsulation. Includes players, teams, scoring, toss, and match summary features.”
